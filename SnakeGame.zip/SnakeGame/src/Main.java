import view.SnakeGame;

import javax.swing.SwingUtilities;
public class Main {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                SnakeGame snakeGame = new SnakeGame();
                snakeGame.startGame();
            }
        });
    }
}