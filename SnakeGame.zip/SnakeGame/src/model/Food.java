package model;

import java.awt.*;
import java.util.Random;

public class Food {
    private static final int UNIT_SIZE = 20;
    private int foodX;
    private int foodY;
    private final SnakeGameBoard gameBoard;
    private final Random random;

    public Food(SnakeGameBoard gameBoard) {
        this.gameBoard = gameBoard;
        random = new Random();
        newFoodPosition();
    }

    public void newFoodPosition() {
        // generating random positions for the food
        foodX = random.nextInt(gameBoard.getWidth());
        foodY = random.nextInt(gameBoard.getHeight());
        while (gameBoard.isCellOccupied(foodX, foodY)) {
            foodX = random.nextInt(gameBoard.getWidth());
            foodY = random.nextInt(gameBoard.getHeight());
        }
    }

    public int getFoodX() {
        return foodX;
    }

    public int getFoodY() {
        return foodY;
    }

    public void draw(Graphics g) {
        // displaying food on the game board
        g.setColor(Color.RED);
        g.fillRect(foodX * UNIT_SIZE, foodY * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
    }
}
