package model;

import java.awt.*;

public class Snake {
    private static final int UNIT_SIZE = 20;
    private int[] x;
    private int[] y;
    private int bodyParts;
    private char direction;
    private final SnakeGameBoard gameBoard;

    public Snake(SnakeGameBoard gameBoard) {
        this.gameBoard = gameBoard;
        bodyParts = 2;
        direction = 'R';

        x = new int[gameBoard.getWidth() * gameBoard.getHeight()];
        y = new int[gameBoard.getWidth() * gameBoard.getHeight()];
        for (int i = 0; i < bodyParts; i++) {
            x[i] = gameBoard.getWidth() / 2 - i;
            y[i] = gameBoard.getHeight() / 2;
            gameBoard.placeSnakePart(x[i], y[i]);
        }
    }

    public void move() {

        for (int i = bodyParts; i > 0; i--) {
            x[i] = x[i - 1];
            y[i] = y[i - 1];
        }

        switch (direction) {
            case 'U':
                y[0]--;
                break;
            case 'D':
                y[0]++;
                break;
            case 'L':
                x[0]--;
                break;
            case 'R':
                x[0]++;
                break;
        }
    }

    public void draw(Graphics g) {
        for (int i = 0; i < bodyParts; i++) {
            if (i == 0) {
                g.setColor(Color.GREEN);
                g.fillRect(x[i] * UNIT_SIZE, y[i] * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
            } else {
                g.setColor(Color.YELLOW);
                g.fillRect(x[i] * UNIT_SIZE, y[i] * UNIT_SIZE, UNIT_SIZE, UNIT_SIZE);
            }
        }
    }

    public void grow() {
        bodyParts++;
    }

    public boolean checkCollisions() {
        if (x[0] < 0 || x[0] >= gameBoard.getWidth() || y[0] < 0 || y[0] >= gameBoard.getHeight()) {
            return true;
        }
        for (int i = bodyParts; i > 0; i--) {
            if (x[0] == x[i] && y[0] == y[i]) {
                return true;
            }
        }
        return false;
    }

    public int getBodyParts() {
        return bodyParts;
    }

    public void setDirection(char direction) {
        this.direction = direction;
    }

    public int[] getX() {
        return x;
    }

    public int[] getY() {
        return y;
    }
}
