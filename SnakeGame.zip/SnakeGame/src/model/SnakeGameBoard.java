package model;

public class SnakeGameBoard {
    private final boolean[][] board;
    private final int width;
    private final int height;

    public SnakeGameBoard(int width, int height) {
        this.width = width;
        this.height = height;
        board = new boolean[width][height];
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                board[i][j] = false;
            }
        }
    }

    public boolean[][] getBoard() {
        return board;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public void placeFood(int x, int y) {
        board[x][y] = true;
    }

    public void removeFood(int x, int y) {
        board[x][y] = false;
    }

    public void placeSnakePart(int x, int y) {
        board[x][y] = true;
    }

    public void removeSnakePart(int x, int y) {
        board[x][y] = false;
    }

    public boolean isCellOccupied(int x, int y) {
        return board[x][y];
    }
}
