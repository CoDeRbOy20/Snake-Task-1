package view;

import model.Food;
import model.Snake;
import model.SnakeGameBoard;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class SnakeGame extends JFrame implements KeyListener {
    public static final int WIDTH = 400;
    public static final int HEIGHT = 400;
    public static final int UNIT_SIZE = 20;
    public static final int GAME_UNITS = (WIDTH * HEIGHT) / (UNIT_SIZE * UNIT_SIZE);
    public static final int SPEED = 200;//adjusing the speed of the snake
    private final SnakeGameBoard gameBoard;
    private final Snake snake;
    private final Food food;
    private boolean running = false;
    private Timer timer;

    public SnakeGame() {
        gameBoard = new SnakeGameBoard(WIDTH / UNIT_SIZE, HEIGHT / UNIT_SIZE);
        snake = new Snake(gameBoard);
        food = new Food(gameBoard);
        this.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        this.setBackground(Color.BLACK);
        this.setFocusable(true);
        this.addKeyListener(this);
        this.getContentPane().setLayout(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        startGame();
    }

    public void startGame() {
        running = true;
        timer = new Timer(SPEED, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (running) {
                    snake.move();
                    checkFood();
                    checkCollisions();
                    repaint();
                }
            }
        });
        timer.start();
    }

    public void paint(Graphics g) {
        super.paint(g);
        snake.draw(g);
        food.draw(g);
    }

    public void checkFood() {
        if (snake.getX()[0] == food.getFoodX() && snake.getY()[0] == food.getFoodY()) {
            snake.grow();
            food.newFoodPosition();
        }
    }

    public void checkCollisions() {
        if (snake.checkCollisions()) {
            running = false;
            timer.stop();
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        //changing the direction of the snake
        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT:
                if (snake.getBodyParts() == 1 || snake.getBodyParts() > 1 && snake.getX()[0] - 1 != snake.getX()[1]) {
                    snake.setDirection('L');
                }
                break;
            case KeyEvent.VK_RIGHT:
                if (snake.getBodyParts() == 1 || snake.getBodyParts() > 1 && snake.getX()[0] + 1 != snake.getX()[1]) {
                    snake.setDirection('R');
                }
                break;
            case KeyEvent.VK_UP:
                if (snake.getBodyParts() == 1 || snake.getBodyParts() > 1 && snake.getY()[0] - 1 != snake.getY()[1]) {
                    snake.setDirection('U');
                }
                break;
            case KeyEvent.VK_DOWN:
                if (snake.getBodyParts() == 1 || snake.getBodyParts() > 1 && snake.getY()[0] + 1 != snake.getY()[1]) {
                    snake.setDirection('D');
                }
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    public static void main(String[] args) {
        new SnakeGame();
    }
}
